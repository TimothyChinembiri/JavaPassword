
import java.util.Scanner;

class NewClass
{
    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
        Scanner scan = new Scanner(System.in);
        System.out.println("********************");
        System.out.println("Enter the password");
        String inputPassword = scan.next();
        int uppercase = 0;
        int lowercase = 0;
        int specialcharacters = 0;
        int digits = 0;
        char[] Password = inputPassword.toCharArray();
        for (int index = 0; index < inputPassword.length(); index++)
        {
            if (Character.isUpperCase(Password[index]))
            {
                uppercase = 1;
            }
            if (Character.isLowerCase(Password[index]))
            {
                lowercase = 1;
            }
            if (Character.isDigit(Password[index]))
            {
                digits = 1;
            }
        }
        if (inputPassword.contains("~") || inputPassword.contains("!") || inputPassword.contains("@")
            || inputPassword.contains("#") || inputPassword.contains("$") || inputPassword.contains("%")
            || inputPassword.contains("^") || inputPassword.contains("&") || inputPassword.contains("*")) ;
        {
            specialcharacters = 1;
        }
        if (inputPassword.length() < 8)

            System.out.println("Too Short");

        if (inputPassword.length() >= 8 && (((uppercase == 1) && (lowercase == 1)) || (digits == 1) || (specialcharacters == 1)))

            System.out.println("Weak");

        if ((inputPassword.length() >= 8 && (((uppercase == 1) && (lowercase == 1)) || (digits == 1) && (specialcharacters == 1)))
            &&
            (inputPassword.length() >= 8 && (((uppercase == 1) && (lowercase == 1)) && (digits == 1) || (specialcharacters == 1))))

            System.out.println("Medium");

        if (inputPassword.length() >= 8 && (uppercase == 1) && (lowercase == 1) && (digits == 1) && (specialcharacters == 1))

            System.out.println("Strong");

    }
}